"""
post_processing_pupil
Python package to calculte output fixation points produced by the pupil-core eye tracker

"""

__version__ = "0.1.5"
__author__ = 'Laura Wenclik'
__credits__ = 'IGN'